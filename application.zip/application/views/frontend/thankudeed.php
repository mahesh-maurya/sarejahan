<div class="container">
    <div class="row">
        <div class="col-md-3"></div>

        <div class="col-md-6">
            <div class="head-reg text-center">
                <h2>Thank You</h2>
            </div>

        </div>
        <div class="col-md-3"></div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12">

            <div class="links ">
                <a href="<?php echo site_url('website/index');?>">Home</a>|<a href="<?php echo site_url('website/bricks');?>">Wall Of Fame</a>|<a href="">Thank You</a>


             

            </div>
        </div>
    </div>
</div>
<div class="regi">
<div class="container">

    <div class="row">
       
 <div class="col-md-3"></div>
         
          <div class="col-md-6" style="margin-bottom: 46px;">
             <div class="head-reg text-center">
              <h2>"Thank You. Message Submit Sucessfully"</h2>
              </div>
          </div>
          <div class="col-md-3"></div>




</div>
</div>
</div>