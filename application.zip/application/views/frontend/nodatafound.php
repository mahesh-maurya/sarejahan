<br> <div class="container">
      <div class="row">
          <div class="col-md-12">
                       <div class="links ">
<!--                  <a href="index.html">Home</a>|<a href="regiments.html">Regiments</a>|<a href="detail.html">Martyr Detail</a>-->

               
                  <a href="<?php echo site_url('website/index');?>">Home</a>|<a href="#">Martyr Detail</a>

              </div>
          </div>
      </div>
  </div>
  <div class="container">
      <div class="row">
         <div class="col-md-3"></div>
         
          <div class="col-md-6">
             <div class="head-reg text-center">
              <h2>No Data Found!!!</h2>
              </div>
          </div>
          <div class="col-md-3"></div>
      </div>
  </div>
  
    
    </div>
    