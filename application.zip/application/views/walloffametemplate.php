<?php

$this->load->view("frontend/walloffameheader");
$this->load->view("frontend/$page");
$this->load->view("frontend/footer");


?>